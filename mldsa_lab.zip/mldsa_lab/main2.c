#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "api.h"


void print_hex(const char *name,
               const uint8_t *data,
               size_t len)
{
    printf("%s (%zu bytes)\n", name, len);

    for(size_t i = 0; i < len; i++)
    {
        printf("%02X", data[i]);

        if((i + 1) % 128 == 0)
            printf("\n");
    }

    printf("\n\n");
}


int main(){
    printf("ML-DSA87 Demo\n");
    uint8_t public_key1[PQCLEAN_MLDSA87_CLEAN_CRYPTO_PUBLICKEYBYTES];
    uint8_t secret_key1[PQCLEAN_MLDSA87_CLEAN_CRYPTO_SECRETKEYBYTES];
    uint8_t signature1[PQCLEAN_MLDSA87_CLEAN_CRYPTO_BYTES];
    size_t signature_len;

    uint8_t public_key2[PQCLEAN_MLDSA87_CLEAN_CRYPTO_PUBLICKEYBYTES];
    uint8_t secret_key2[PQCLEAN_MLDSA87_CLEAN_CRYPTO_SECRETKEYBYTES];
    uint8_t signature2[PQCLEAN_MLDSA87_CLEAN_CRYPTO_BYTES];
  
    


    char message[]="chandu bro";

    size_t message_len= strlen(message);

    int keypair1;
    int verfi1;
    int sign_signa1;

    int keypair2;
    int verfi2;
    int sign_signa2;
    
    keypair1=PQCLEAN_MLDSA87_CLEAN_crypto_sign_keypair(public_key1, secret_key1);
    keypair2=PQCLEAN_MLDSA87_CLEAN_crypto_sign_keypair(public_key2, secret_key2);


    if(keypair1 !=0){ 
        printf(" 1 key genetation failed!\n");
        return -1; } 
    else{ 
        printf("1 key generation successful !\n"); 
        // printf("1 public key size : %zu bytes \n",  (size_t)PQCLEAN_MLDSA87_CLEAN_CRYPTO_PUBLICKEYBYTES );
        // printf("1 secret key size : %zu bytes \n",  (size_t)PQCLEAN_MLDSA87_CLEAN_CRYPTO_SECRETKEYBYTES );

        print_hex("public_key 1",public_key1,64);
        print_hex("secret_key 1",secret_key1,64);
    }

    if(keypair2 !=0){ 
        printf(" 2 key genetation failed!\n");
        return -1; } 
    else{ 
        printf("2 key generation successful !\n"); 
        // printf("2 public key size : %zu bytes \n",  (size_t)PQCLEAN_MLDSA87_CLEAN_CRYPTO_PUBLICKEYBYTES );
        // printf("2 secret key size : %zu bytes \n",  (size_t)PQCLEAN_MLDSA87_CLEAN_CRYPTO_SECRETKEYBYTES );

        print_hex("public_key 2",public_key2,64);
        print_hex("secret_key 2",secret_key2,64);
    }

    

    
    


    sign_signa1 = PQCLEAN_MLDSA87_CLEAN_crypto_sign_signature(signature1, &signature_len, (const uint8_t *)message,  message_len, secret_key1 );

    

    sign_signa2 = PQCLEAN_MLDSA87_CLEAN_crypto_sign_signature(signature2, &signature_len, (const uint8_t *)message,  message_len, secret_key1 );



    if(sign_signa1 !=0){
        printf("signature 1 genetation failed!\n");
        return -1;
    }
    else{
        printf("signature 1 generation successful !\n");
        // printf("Signature 1 Length : %zu bytes\n", signature_len);
        print_hex("signature 1",signature1,64);

    }
    
    if(sign_signa2 !=0){
        printf("signature 2 genetation failed!\n");
        return -1;
    }
    else{
        printf("signature 2 generation successful !\n");
        // printf("Signature 2 Length : %zu bytes\n", signature_len);
        print_hex("signature 2",signature2,64);

    }
    
    message[0]='c';
    verfi1 = PQCLEAN_MLDSA87_CLEAN_crypto_sign_verify(signature1, signature_len, (const uint8_t *)message, message_len,public_key1);


    verfi2 = PQCLEAN_MLDSA87_CLEAN_crypto_sign_verify(signature2, signature_len, (const uint8_t *)message, message_len,public_key1);

    if(verfi1 ==0)
        {
         printf("1 Verification SUCCESS\n");
        }
    else
        {
            printf("1 Verification FAILED\n");
        }

    if(verfi2 ==0)
        {
         printf("2 Verification SUCCESS\n");
        }
    else
        {
            printf("2 Verification FAILED\n");
        }

    




    return 0;
}