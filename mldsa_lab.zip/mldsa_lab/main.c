#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "api.h"

void print_hex(const char *name, const uint8_t *data, size_t len) {
  printf("%s (%zu bytes)\n", name, len);

  for (size_t i = 0; i < len; i++) {
    printf("%02X", data[i]);

    if ((i + 1) % 128 == 0)
      printf("\n");
  }

  printf("\n\n");
}

int main() {
  printf("ML-DSA87 Demo\n");
  uint8_t public_key[PQCLEAN_MLDSA87_CLEAN_CRYPTO_PUBLICKEYBYTES];
  uint8_t secret_key[PQCLEAN_MLDSA87_CLEAN_CRYPTO_SECRETKEYBYTES];
  uint8_t signature[PQCLEAN_MLDSA87_CLEAN_CRYPTO_BYTES];
  size_t signature_len;

  char message[] = "chandu bro";
  size_t message_len = strlen(message);

  int keypair;
  int verfi;
  int sign_signa;

  keypair = PQCLEAN_MLDSA87_CLEAN_crypto_sign_keypair(public_key, secret_key);

  if (keypair != 0) {
    printf("key genetation failed!\n");
    return -1;
  } else {
    printf("key generation successful !\n");
  }

  printf("public key size : %zu bytes \n",
         (size_t)PQCLEAN_MLDSA87_CLEAN_CRYPTO_PUBLICKEYBYTES);
  printf("secret key size : %zu bytes \n",
         (size_t)PQCLEAN_MLDSA87_CLEAN_CRYPTO_SECRETKEYBYTES);

  print_hex("public_key", public_key, 64);
  print_hex("secret_key", secret_key, 64);

  sign_signa = PQCLEAN_MLDSA87_CLEAN_crypto_sign_signature(
      signature, &signature_len, (const uint8_t *)message, message_len,
      secret_key);

  if (sign_signa != 0) {
    printf("signature genetation failed!\n");
    return -1;
  } else {
    printf("signature generation successful !\n");
    printf("Signature Length : %zu bytes\n", signature_len);
    print_hex("signature", signature, 64);
  }

  message[0] = 'c';
  verfi = PQCLEAN_MLDSA87_CLEAN_crypto_sign_verify(signature, signature_len,
                                                   (const uint8_t *)message,
                                                   message_len, public_key);

  if (verfi == 0) {
    printf("Verification SUCCESS\n");
  } else {
    printf("Verification FAILED\n");
  }

  return 0;
}