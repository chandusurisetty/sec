#include <stdint.h>
#include <stdio.h>

#include "../crypto/sb_crypto.h"

int main() {
  uint8_t public_key[PQCLEAN_MLDSA87_CLEAN_CRYPTO_PUBLICKEYBYTES];
  uint8_t secret_key[PQCLEAN_MLDSA87_CLEAN_CRYPTO_SECRETKEYBYTES];

  int keypair = sb_generate_keypair(public_key, secret_key);

  if (keypair != 0) {
    printf("Key generation failed!\n");
    return -1;
  } else {
    printf("Key generation successful!\n");

    FILE *pub_file = fopen("keys/root_public.key", "wb");
    FILE *sec_file = fopen("keys/root_private.key", "wb");

    if (pub_file == NULL || sec_file == NULL) {
      printf("Error: Could not open file for writing.\n");
      return -1;
    }

    size_t pub_bytes_written = fwrite(
        public_key, 1, PQCLEAN_MLDSA87_CLEAN_CRYPTO_PUBLICKEYBYTES, pub_file);

    size_t sec_bytes_written = fwrite(
        secret_key, 1, PQCLEAN_MLDSA87_CLEAN_CRYPTO_SECRETKEYBYTES, sec_file);

    fclose(pub_file);
    fclose(sec_file);

    if (pub_bytes_written == PQCLEAN_MLDSA87_CLEAN_CRYPTO_PUBLICKEYBYTES) {
      printf("Public key saved : keys/root_public.key\n ");
    } else {
      printf("failed to created public key ");
    }

    if (sec_bytes_written == PQCLEAN_MLDSA87_CLEAN_CRYPTO_SECRETKEYBYTES) {
      printf("Private key saved: keys/root_private.key\n");
    } else {
      printf("failed to created private key ");
    }
  }

  return 0;
}
