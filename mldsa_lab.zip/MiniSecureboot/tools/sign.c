#include "../crypto/sb_crypto.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>

int main() {
  //     uint8_t public_key[PQCLEAN_MLDSA87_CLEAN_CRYPTO_PUBLICKEYBYTES];
  //   uint8_t secret_key[PQCLEAN_MLDSA87_CLEAN_CRYPTO_SECRETKEYBYTES];
  uint8_t signature[PQCLEAN_MLDSA87_CLEAN_CRYPTO_BYTES];
  size_t signature_len;
  const char message[] = "chandu";
  size_t message_len = strlen(message);

  int signature_values = sb_sign(message, message_len, secret_key, signature, &signature_len);

  return 0;
}